$(document).ready(function () {

    $('.section-features').waypoints(function(direction) {
        if (direction == "down") {
            $('nav').addClass('sticky');
        } else {
            $('nav').removeClass('sticky');
        }
    }, {
        offset: '60px;'
    });

});

/* http://imakewebthings.com/waypoints/guides/jquery-zepto/ 
    THE WEBSITE WHICH I GOT THE CODE FROM */